import os
from sqlalchemy import ForeignKey, Column, String, Integer, \
                    DateTime, create_engine
from sqlalchemy.orm import relationship
from flask_sqlalchemy import SQLAlchemy
import json
import os
from flask_migrate import Migrate
from datetime import datetime

database_filename = "database.db"
project_dir = os.path.dirname(os.path.abspath(__file__))
database_path = "sqlite:///{}" \
        .format(os.path.join(project_dir, database_filename))

db = SQLAlchemy()

'''
setup_db(app)
    binds a flask application and a SQLAlchemy service
'''
def setup_db(app):
    app.config["SQLALCHEMY_DATABASE_URI"] = database_path
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    db.app = app
    db.init_app(app)
    db.create_all()

def db_drop_and_create_all():
    db.drop_all()
    db.create_all()
    db_first_row()

def db_first_row():
    '''this will initialize the database with some test records.'''

    new_actor = (Actor(
        name = 'Kiefer Sutherland',
        role = 'Actor',
        movie_id = "1"
        ))

    new_movie = (Movie(
        title = '24',
        year = "2001"
        ))

    new_movie.insert()
    new_actor.insert()
    db.session.commit()

class Actor(db.Model):
    id = Column(Integer().with_variant(Integer, "sqlite"), primary_key=True)
    name = Column(String(80), nullable=False)
    role = Column(String(50), nullable=False)
    movie_id = Column(Integer, ForeignKey('movie.id'), nullable=True)

    def __init__(self, name, role, movie_id):
        self.name = name
        self.role = role
        self.movie_id = movie_id

    def insert(self):
        db.session.add(self)
        db.session.commit()

    def delete(self):
        db.session.delete(self)
        db.session.commit()

    def update(self):
        db.session.commit()

    def format(self):
        return {
            'id': self.id,
            'name': self.name,
            'role': self.role,
            'movie_id': self.movie_id
        }
    def long(self):
        try:
            return {
            'id': self.id,
            'name': self.name,
            'role': self.role,
            'movie_id': self.movie_id
        }
        except Exception as e:

            return {
                'id': self.id,
                'name': self.name,
                'role': self.role
            }
    def short(self):
        try:
            return {
            'id': self.id,
            'name': self.name,
            'role': self.role
        }
        except Exception as e:

            return {
                'id': self.id,
                'name': self.name,
                'role': self.role
            }
    def __repr__(self):
        return json.dumps(self.short())

class Movie(db.Model):
    id = Column(Integer, primary_key=True)
    title = Column(String)
    year = Column(String)
    actors = relationship('Actor', backref="movie", lazy=True)

    
    def short(self):
        #print(self.)
        short_movie = [{'title': r['title'], 'year': r['year']}
                        for r in json.loads(self.title)]
        return {
            'id': self.id,
            'title': self.title,
            'year': self.year
        }

     
    def long(self):
        try:
            return {
            'id': self.id,
            'title': self.title,
            'year': self.year
        }
        except Exception as e:

            return {
                'id': self.id,
                'title': self.title,
                'year': self.year
            }


    
    def insert(self):
        db.session.add(self)
        db.session.commit()

    def delete(self):
        db.session.delete(self)
        db.session.commit()
     
    def update(self):
        db.session.commit()

    def __repr__(self):
        return json.dumps(self.short())