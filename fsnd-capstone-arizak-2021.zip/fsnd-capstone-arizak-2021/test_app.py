import os
import unittest
import json
from flask_sqlalchemy import SQLAlchemy
from app import create_app
from models import Actor, Movie, setup_db, db_drop_and_create_all

#database_path = 'postgresql://postgres:123456@localhost:5432/capstone'

class AgencyTestCase(unittest.TestCase):

    # def setup(self):

    #     self.Auth_assistant = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkVKSnJlUUpvSmxjd1J3V2dMZlJmdSJ9.eyJpc3MiOiJodHRwczovL2FyaXphay51cy5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWY3ZGVmYmVlMzQzYjMwMDZmY2E2OTJhIiwiYXVkIjoiY2Fwc3RvbmUiLCJpYXQiOjE2MDk3NzA3OTksImV4cCI6MTYwOTg1NzE5OSwiYXpwIjoidVo3aUlYSGUxNkJqRWZsWFdjOFM0T09WZFpRWXJBdFUiLCJzY29wZSI6IiIsInBlcm1pc3Npb25zIjpbImRlbGV0ZTphY3RvcnMiLCJkZWxldGU6bW92aWVzIiwiZ2V0OmFjdG9ycyIsImdldDptb3ZpZXMiLCJwYXRjaDphY3RvcnMiLCJwYXRjaDptb3ZpZXMiLCJwb3N0OmFjdG9ycyIsInBvc3Q6bW92aWVzIl19.RG68BDDo6VhitwvYX_G2lUONaMbbsQVKMZVbT5pSE0DGDpJitnqbMDZ48L7X1kJbh-BshOYIsOQtzbr0Z9wbvqN0ZLWZPqnzIbeQ8wQv3hNyDL44OtMs3pa5_38XRuExCTS7jkh8vGD16O52qaZshwVq6th6aTpziEFBknfy6RaoreAGLTuKpMcC023YLHURkFxSUfOEaAePWnOS1WAZQfbt5ztpfR03ib65WrM5lBk-_GtLBDajba3_djeLpj9B1We04bL3PtCpd3fwX_MaNVWdCKK5uDC-TifBeTrKQV4SIGJ1VRhHicyK5y1WMtee3OZQGb0Th4Y8No5jQt80TA"
    #     self.Auth_director =  "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkVKSnJlUUpvSmxjd1J3V2dMZlJmdSJ9.eyJpc3MiOiJodHRwczovL2FyaXphay51cy5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWY3ZGVmYmVlMzQzYjMwMDZmY2E2OTJhIiwiYXVkIjoiY2Fwc3RvbmUiLCJpYXQiOjE2MDk3NzA3OTksImV4cCI6MTYwOTg1NzE5OSwiYXpwIjoidVo3aUlYSGUxNkJqRWZsWFdjOFM0T09WZFpRWXJBdFUiLCJzY29wZSI6IiIsInBlcm1pc3Npb25zIjpbImRlbGV0ZTphY3RvcnMiLCJkZWxldGU6bW92aWVzIiwiZ2V0OmFjdG9ycyIsImdldDptb3ZpZXMiLCJwYXRjaDphY3RvcnMiLCJwYXRjaDptb3ZpZXMiLCJwb3N0OmFjdG9ycyIsInBvc3Q6bW92aWVzIl19.RG68BDDo6VhitwvYX_G2lUONaMbbsQVKMZVbT5pSE0DGDpJitnqbMDZ48L7X1kJbh-BshOYIsOQtzbr0Z9wbvqN0ZLWZPqnzIbeQ8wQv3hNyDL44OtMs3pa5_38XRuExCTS7jkh8vGD16O52qaZshwVq6th6aTpziEFBknfy6RaoreAGLTuKpMcC023YLHURkFxSUfOEaAePWnOS1WAZQfbt5ztpfR03ib65WrM5lBk-_GtLBDajba3_djeLpj9B1We04bL3PtCpd3fwX_MaNVWdCKK5uDC-TifBeTrKQV4SIGJ1VRhHicyK5y1WMtee3OZQGb0Th4Y8No5jQt80TA"
    #     self.Auth_producer  = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkVKSnJlUUpvSmxjd1J3V2dMZlJmdSJ9.eyJpc3MiOiJodHRwczovL2FyaXphay51cy5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWY3ZGVmYmVlMzQzYjMwMDZmY2E2OTJhIiwiYXVkIjoiY2Fwc3RvbmUiLCJpYXQiOjE2MDk3NzA3OTksImV4cCI6MTYwOTg1NzE5OSwiYXpwIjoidVo3aUlYSGUxNkJqRWZsWFdjOFM0T09WZFpRWXJBdFUiLCJzY29wZSI6IiIsInBlcm1pc3Npb25zIjpbImRlbGV0ZTphY3RvcnMiLCJkZWxldGU6bW92aWVzIiwiZ2V0OmFjdG9ycyIsImdldDptb3ZpZXMiLCJwYXRjaDphY3RvcnMiLCJwYXRjaDptb3ZpZXMiLCJwb3N0OmFjdG9ycyIsInBvc3Q6bW92aWVzIl19.RG68BDDo6VhitwvYX_G2lUONaMbbsQVKMZVbT5pSE0DGDpJitnqbMDZ48L7X1kJbh-BshOYIsOQtzbr0Z9wbvqN0ZLWZPqnzIbeQ8wQv3hNyDL44OtMs3pa5_38XRuExCTS7jkh8vGD16O52qaZshwVq6th6aTpziEFBknfy6RaoreAGLTuKpMcC023YLHURkFxSUfOEaAePWnOS1WAZQfbt5ztpfR03ib65WrM5lBk-_GtLBDajba3_djeLpj9B1We04bL3PtCpd3fwX_MaNVWdCKK5uDC-TifBeTrKQV4SIGJ1VRhHicyK5y1WMtee3OZQGb0Th4Y8No5jQt80TA"
    #     self.app = create_app()
    #     self.testing = True
    #     self.client = self.app.test_client
    
    #     db.drop_all()
    #     db.create_all()
    def setUp(self):
        self.app = create_app()
        self.client = self.app.test_client

        self.Auth_assistant = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkVKSnJlUUpvSmxjd1J3V2dMZlJmdSJ9.eyJpc3MiOiJodHRwczovL2FyaXphay51cy5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWZiNGJmOGExMThkMGYwMDZmYTAwMWNlIiwiYXVkIjoiY2Fwc3RvbmUiLCJpYXQiOjE2MDk4NjM2MDksImV4cCI6MTYwOTk1MDAwOSwiYXpwIjoidVo3aUlYSGUxNkJqRWZsWFdjOFM0T09WZFpRWXJBdFUiLCJzY29wZSI6IiIsInBlcm1pc3Npb25zIjpbImdldDphY3RvcnMiLCJnZXQ6bW92aWVzIl19.hFlqkytN4embhIuL58CpCSzyGIb3atIgy5WF7wNyr69Meq4vi6hyWxVeFVN7bec985PQyAB0TP8WwLdHhlIHQ_33cuhClweBlIPaIwRZEKcudg6S2EAri-qXaBCUyCLW7eyjm3NUOvy1p5CwPPYON9RVpD3bMQwT8L0gPmr5d4lxXeAy7AsGqFl5VJLC3VPYrtG8Q6rFgrHtV8vGB4BiEwd9pM7oj6SlBigrpIUsDNN5DgbSdMEs9pBCNQlGj4k3DekBoosvTUbnpL2Q-_cBP-ylL3uUCcLpxlbMXHkddEUoIkmW3xpDzdrENWir6KIQvSRWAsFlZnt-fZs3Qw6GWA"
        self.Auth_director =  "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkVKSnJlUUpvSmxjd1J3V2dMZlJmdSJ9.eyJpc3MiOiJodHRwczovL2FyaXphay51cy5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWY3ZGVmYmVlMzQzYjMwMDZmY2E2OTJhIiwiYXVkIjoiY2Fwc3RvbmUiLCJpYXQiOjE2MDk4NTc1MjMsImV4cCI6MTYwOTk0MzkyMywiYXpwIjoidVo3aUlYSGUxNkJqRWZsWFdjOFM0T09WZFpRWXJBdFUiLCJzY29wZSI6IiIsInBlcm1pc3Npb25zIjpbImRlbGV0ZTphY3RvcnMiLCJkZWxldGU6bW92aWVzIiwiZ2V0OmFjdG9ycyIsImdldDptb3ZpZXMiLCJwYXRjaDphY3RvcnMiLCJwYXRjaDptb3ZpZXMiLCJwb3N0OmFjdG9ycyIsInBvc3Q6bW92aWVzIl19.QDU7KKOdX9KRqt8ZZ18NuO0rQUaGgncrL6a4QxD1HQ-zY8CRJZKHk3iD8DE4OkznPP7EhNLkg9-onMpkrUmw3EAjh-O7J8An_D4Wt0X1Tm48H-eKo1NimwBfkKQzvkGHUrY7EDsLjOFHgdjK_KVd8onI0TnWETGM5h3nlnqq42Hf8UHroctJGAYpK7gXCryt5xtsPKJLncnJ2zMNyLaZWSzS5XChItnF6h9XarnZuUhB6oElhUFG_zo4YXGOJ44IWjEUG_JrjGcOJsB2LsXdQMXYoln-mjRQLEgvqKn1zeVlDWq6tABf6Hps78oPCfkXrKFnfZsJjRT6O747l4fPGQ"
        self.Auth_producer  = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkVKSnJlUUpvSmxjd1J3V2dMZlJmdSJ9.eyJpc3MiOiJodHRwczovL2FyaXphay51cy5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWZlNzBmYmE0NTIyNjgwMDc1NWEzYmZhIiwiYXVkIjoiY2Fwc3RvbmUiLCJpYXQiOjE2MDk4NjQ5MzcsImV4cCI6MTYwOTk1MTMzNywiYXpwIjoidVo3aUlYSGUxNkJqRWZsWFdjOFM0T09WZFpRWXJBdFUiLCJzY29wZSI6IiIsInBlcm1pc3Npb25zIjpbImRlbGV0ZTphY3RvcnMiLCJnZXQ6YWN0b3JzIiwiZ2V0Om1vdmllcyIsInBhdGNoOmFjdG9ycyIsInBhdGNoOm1vdmllcyIsInBvc3Q6YWN0b3JzIl19.NqHC2TEpd_Q-chTKeRQPmFPT05riQloap7l0Tq0PA0Ff2lLlBgSKJvxcidgi9WKBOdvqYqytzikxiyxm72dF0sokA4DPzNFrjsHwa8oX27i0VCx2KFT293sf6aUa1Gx5Q232qTqJ_eU-WOaqm1NZkDua-nghIK3uvT1BZ-vPkhIHgXVu43bVWTZuyonayadxPZyw-p8Js4Guw0ixxjBDwrNELi029x-PJ-SsKRkcYIiBGsI5hQghQ1wTE6NGZzhPoPrl3bEy1CBhC-pQBZ86eRnzhSRTdr5zTEYUyyt3EybDARP-eeEpGEFJn58oMnRXdepm8jqCRNv6PyrHvTc1LQ"

        setup_db(self.app)
        db_drop_and_create_all()
        with self.app.app_context():
            self.db = SQLAlchemy()
            self.db.init_app(self.app)
            # create all tables
            self.db.create_all()
        
        self.new_actor = {
            "name": "test xxxx",
            "role": "assistance",
            "movie_id": "1"
        }
        self.new_movies = {
            "title": "test ",
            "year":  "2020"
        }
    def tearDown(self):
        pass

     
    #----------------------------------------------------------------------------#
    # @TODO: Actors / Movie Test Module
    #----------------------------------------------------------------------------#

    def test_post_success_actor_director(self):
        new_actor = {
            'name' : 'test test',
            'role': 'assistance', 
            "movie_id": "1"
        } 

        res = self.client().post('/actors', json = new_actor, headers={
                                     "Authorization": "Bearer {}".format(
                                         self.Auth_director)
                                 })
         
        data = json.loads(res.data)
        print(data)
        self.assertEqual(res.status_code, 200)
        self.assertTrue(data['success'])
    def test_post_success_movie_director(self):
        res = self.client().post('/movies', json = self.new_movies, headers={
                                     "Authorization": "Bearer {}".format(
                                         self.Auth_director)
                                 })
         
        data = json.loads(res.data)
        print(res.data)
        self.assertEqual(res.status_code, 200)
        self.assertTrue(data['success'])

    # Tests get actors 
    def test_get_success_actor(self):
        res = self.client().get('/actors',  headers={
                                     "Authorization": "Bearer {}".format(
                                         self.Auth_director)
                                 })
        data = json.loads(res.data)
        self.assertEqual(res.status_code, 200)
        self.assertTrue(data['success'])
        self.assertTrue(len(data['actors']) > 0)

    def test_get_actors_fail(self):
        res = self.client().get('/actors')
        self.assertEqual(res.status_code, 404)


    def test_create_movie(self):
        res = self.client().post('/movies/create', json=self.new_movie)
        data = json.loads(res.data)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data['success'], True)
        self.assertEqual(data['new_movie']['title'], 'New Movie')

    def test_create_actor(self):
        res = self.client().post('/actors/create', json=self.new_actor)
        data = json.loads(res.data)
        print(res.data)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data['success'], True)
        self.assertEqual(data['new_actor']['name'], 'John Doe')
    
    def test_delete_movie(self):
        res = self.client().delete('/movies/delete/1')
        data = json.loads(res.data)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data['success'], True)
    
    def test_delete_movie_fail(self):
        res = self.client().delete('/movies/delete/1000')
        self.assertEqual(res.status_code, 404)
    
    def test_delete_actor(self):
        res = self.client().delete('/actors/delete/1')
        data = json.loads(res.data)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data['success'], True)
    
    def test_delete_actor_fail(self):
        res = self.client().delete('/actors/delete/1000')
        self.assertEqual(res.status_code, 404)
    
    def test_patch_movie(self):
        res = self.client().patch('/movies/patch/2', json=self.new_movie)
        data = json.loads(res.data)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data['success'], True)
    
    def test_patch_movie_fail(self):
        res = self.client().patch('/movies/patch/2000', json=self.new_movie)
        self.assertEqual(res.status_code, 404)

    
    def test_patch_actor(self):
        res = self.client().patch('/actors/patch/2', json=self.new_actor)
        data = json.loads(res.data)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(data['success'], True)
    
    def test_patch_actor_fail(self):
        res = self.client().patch('/actors/patch/2000', json=self.new_actor)
        self.assertEqual(res.status_code, 404)

    
if __name__ == "__main__":
    unittest.main()
